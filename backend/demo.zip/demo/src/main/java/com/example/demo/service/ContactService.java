package com.example.demo.service;


import com.example.demo.dto.ContactDTO;
import com.example.demo.model.Contact;
import com.example.demo.model.User;
import com.example.demo.repository.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;

@Service
public class ContactService {

    @Autowired
    private ContactRepository contactRepository;

    @Autowired
    private UserService userService;

    public Contact addContact(ContactDTO contactDTO) {
        User user = userService.getUserById(contactDTO.getUserId());

        Contact contact = new Contact();
        contact.setName(contactDTO.getName());
        contact.setPhoneNumber(contactDTO.getPhoneNumber());
        contact.setEmail(contactDTO.getEmail());
        contact.setRelationship(contactDTO.getRelationship());
        contact.setUser(user);

        return contactRepository.save(contact);
    }

    public List<Contact> getContactsByUserId(Long userId) {
        // Vérifier si l'utilisateur existe
        userService.getUserById(userId);
        return contactRepository.findByUserId(userId);
    }

    public Contact getContactById(Long id) {
        return contactRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Contact non trouvé avec l'ID: " + id));
    }

    public Contact updateContact(Long id, ContactDTO contactDTO) {
        Contact existingContact = getContactById(id);
        User user = userService.getUserById(contactDTO.getUserId());

        existingContact.setName(contactDTO.getName());
        existingContact.setPhoneNumber(contactDTO.getPhoneNumber());
        existingContact.setEmail(contactDTO.getEmail());
        existingContact.setRelationship(contactDTO.getRelationship());
        existingContact.setUser(user);

        return contactRepository.save(existingContact);
    }

    public void deleteContact(Long id) {
        Contact contact = getContactById(id);
        contactRepository.delete(contact);
    }
}