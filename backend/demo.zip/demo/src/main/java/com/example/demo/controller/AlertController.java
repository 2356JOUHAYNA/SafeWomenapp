package com.example.demo.controller;

import com.example.demo.dto.AlertRequestDTO;
import com.example.demo.model.Alert;
import com.example.demo.service.AlertService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*") // Autorise les appels externes (Android par ex.)
@RestController
@RequestMapping("/api/alerts")
public class AlertController {

    private static final Logger logger = LoggerFactory.getLogger(AlertController.class);

    @Autowired
    private AlertService alertService;

    @PostMapping("/user/{userId}")
    @PreAuthorize("authentication.principal.id == #userId")
    public ResponseEntity<?> createAlert(@PathVariable Long userId, @Valid @RequestBody AlertRequestDTO alertRequestDTO) {
        try {
            Alert alert = alertService.createAlert(userId, alertRequestDTO);
            logger.info("🚨 Alerte créée pour l’utilisateur ID {}", userId);
            return new ResponseEntity<>(alert, HttpStatus.CREATED);
        } catch (Exception e) {
            logger.error("Erreur création alerte : {}", e.getMessage());
            return new ResponseEntity<>(Map.of("error", e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("authentication.principal.id == #userId")
    public ResponseEntity<List<Alert>> getAlertsByUserId(@PathVariable Long userId) {
        List<Alert> alerts = alertService.getAlertsByUserId(userId);
        return new ResponseEntity<>(alerts, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getAlertById(@PathVariable Long id) {
        try {
            Alert alert = alertService.getAlertById(id);
            return new ResponseEntity<>(alert, HttpStatus.OK);
        } catch (Exception e) {
            logger.warn("Alerte introuvable ID {}", id);
            return new ResponseEntity<>(Map.of("error", e.getMessage()), HttpStatus.NOT_FOUND);
        }
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<?> updateAlertStatus(@PathVariable Long id, @RequestBody Map<String, String> statusUpdate) {
        try {
            String status = statusUpdate.get("status");
            if (status == null) {
                return new ResponseEntity<>(Map.of("error", "Le statut est requis"), HttpStatus.BAD_REQUEST);
            }

            // Vérifie les statuts valides
            List<String> validStatuses = Arrays.asList("ACTIVE", "RESOLVED", "IGNORED");
            if (!validStatuses.contains(status.toUpperCase())) {
                return new ResponseEntity<>(Map.of("error", "Statut non valide. Choisir : ACTIVE, RESOLVED, IGNORED"), HttpStatus.BAD_REQUEST);
            }

            Alert updatedAlert = alertService.updateAlertStatus(id, status.toUpperCase());
            return new ResponseEntity<>(updatedAlert, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Erreur mise à jour du statut de l’alerte {} : {}", id, e.getMessage());
            return new ResponseEntity<>(Map.of("error", e.getMessage()), HttpStatus.BAD_REQUEST);
        }
    }
}
