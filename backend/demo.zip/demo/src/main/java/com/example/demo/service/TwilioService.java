package com.example.demo.service;

import com.twilio.Twilio;
import com.twilio.exception.ApiException;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

@Service
public class TwilioService {

    private static final Logger LOGGER = Logger.getLogger(TwilioService.class.getName());

    @Value("${twilio.account.sid}")
    private String accountSid;

    @Value("${twilio.auth.token}")
    private String authToken;

    @Value("${twilio.phone.number}")
    private String fromPhoneNumber;

    public Map<String, String> sendSms(String toPhoneNumber, String messageBody) {
        Map<String, String> response = new HashMap<>();

        try {
            Twilio.init(accountSid, authToken);

            Message message = Message.creator(
                    new PhoneNumber(toPhoneNumber),
                    new PhoneNumber(fromPhoneNumber),
                    messageBody
            ).create();

            LOGGER.info("Message sent successfully with SID: " + message.getSid());

            response.put("status", "success");
            response.put("message", "Message envoyé avec succès !");
            response.put("sid", message.getSid());

        } catch (ApiException e) {
            LOGGER.severe("Erreur lors de l'envoi du SMS : " + e.getMessage());
            response.put("status", "error");
            response.put("message", "Erreur lors de l'envoi du SMS : " + e.getMessage());
        }

        return response;
    }
}
