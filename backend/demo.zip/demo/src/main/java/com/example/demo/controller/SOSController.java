package com.example.demo.controller;

import com.example.demo.service.TwilioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/sos")
public class SOSController {

    @Autowired
    private TwilioService twilioService;

    @PostMapping("/send")
    public Map<String, String> sendSOS(@RequestParam String phoneNumber,
                                       @RequestParam double latitude,
                                       @RequestParam double longitude,
                                       @RequestParam(required = false) String audioUrl) {

        StringBuilder message = new StringBuilder();
        message.append("🚨 SOS Alert!\n");
        message.append("📍 Location: ").append(latitude).append(", ").append(longitude).append("\n");

        if (audioUrl != null) {
            message.append("🔊 Audio: ").append(audioUrl);
        } else {
            message.append("Aucun audio disponible.");
        }

        return twilioService.sendSms(phoneNumber, message.toString());
    }
}
