package com.example.demo.service;

import com.example.demo.dto.SOSRequestDTO;
import com.example.demo.model.SOS;
import com.example.demo.repository.SOSRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class SOSService {

    @Autowired
    private SOSRepository sosRepository;

    public SOS saveSOS(SOSRequestDTO sosRequestDTO) {
        SOS sos = new SOS();
        sos.setLatitude(sosRequestDTO.getLatitude());
        sos.setLongitude(sosRequestDTO.getLongitude());
        sos.setAudioFilePath(sosRequestDTO.getAudioFilePath());
        sos.setTimestamp(new Date());
        sos.setStatus("EN COURS");

        return sosRepository.save(sos);
    }
}
