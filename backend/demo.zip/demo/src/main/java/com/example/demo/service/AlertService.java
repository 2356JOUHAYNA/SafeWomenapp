package com.example.demo.service;



import com.example.demo.dto.AlertRequestDTO;
import com.example.demo.model.Alert;
import com.example.demo.model.User;
import com.example.demo.repository.AlertRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
public class AlertService {

    @Autowired
    private AlertRepository alertRepository;

    @Autowired
    private UserService userService;

    @Autowired
    private NotificationService notificationService;

    // Méthode simplifiée pour sauvegarder le fichier audio (dans une implémentation réelle,
    // vous pourriez utiliser Amazon S3, Google Cloud Storage, etc.)
    private String saveAudioRecording(String audioBase64) {
        if (audioBase64 == null || audioBase64.isEmpty()) {
            return null;
        }

        // Simulation de sauvegarde du fichier audio
        String fileName = "audio_" + UUID.randomUUID().toString() + ".wav";
        // Dans une implémentation réelle, vous sauvegarderiez le fichier ici

        return "/recordings/" + fileName;
    }

    public Alert createAlert(Long userId, AlertRequestDTO alertRequestDTO) {
        User user = userService.getUserById(userId);

        Alert alert = new Alert();
        alert.setUser(user);
        alert.setTimestamp(LocalDateTime.now());
        alert.setLatitude(alertRequestDTO.getLatitude());
        alert.setLongitude(alertRequestDTO.getLongitude());
        alert.setStatus("ACTIVE");

        // Sauvegarder l'enregistrement audio si disponible
        if (alertRequestDTO.getAudioBase64() != null && !alertRequestDTO.getAudioBase64().isEmpty()) {
            String audioUrl = saveAudioRecording(alertRequestDTO.getAudioBase64());
            alert.setAudioRecordingUrl(audioUrl);
        }

        Alert savedAlert = alertRepository.save(alert);

        // Envoyer des notifications aux contacts d'urgence
        notificationService.sendSosAlert(savedAlert);

        return savedAlert;
    }

    public List<Alert> getAlertsByUserId(Long userId) {
        // Vérifier si l'utilisateur existe
        userService.getUserById(userId);
        return alertRepository.findByUserIdOrderByTimestampDesc(userId);
    }

    public Alert getAlertById(Long id) {
        return alertRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Alerte non trouvée avec l'ID: " + id));
    }

    public Alert updateAlertStatus(Long id, String status) {
        Alert alert = getAlertById(id);
        alert.setStatus(status);
        return alertRepository.save(alert);
    }
}