package com.example.demo;

public class ChatResponse {
    private String reply;

    public String getReply() {
        return reply;
    }

    public void setReply(String reply) {
        this.reply = reply;
    }
    // Constructor / Getter / Setter
}
