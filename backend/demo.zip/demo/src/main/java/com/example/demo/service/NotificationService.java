package com.example.demo.service;


import com.example.demo.model.Alert;
import com.example.demo.model.Contact;
import com.example.demo.model.User;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.util.List;

@Service
public class NotificationService {

    @Value("${twilio.account.sid}")
    private String twilioAccountSid;

    @Value("${twilio.auth.token}")
    private String twilioAuthToken;

    @Value("${twilio.phone.number}")
    private String twilioPhoneNumber;

    @Autowired
    private ContactService contactService;

    @PostConstruct
    public void init() {
        Twilio.init(twilioAccountSid, twilioAuthToken);
    }

    public void sendSosAlert(Alert alert) {
        User user = alert.getUser();
        List<Contact> emergencyContacts = contactService.getContactsByUserId(user.getId());

        String googleMapsLink = String.format(
                "https://www.google.com/maps/search/?api=1&query=%f,%f",
                alert.getLatitude(),
                alert.getLongitude()
        );

        String messageBody = String.format(
                "ALERTE SOS de %s ! Localisation actuelle: %s",
                user.getFullName(),
                googleMapsLink
        );

        for (Contact contact : emergencyContacts) {
            try {
                Message message = Message.creator(
                        new PhoneNumber(contact.getPhoneNumber()),
                        new PhoneNumber(twilioPhoneNumber),
                        messageBody
                ).create();

                System.out.println("SMS envoyé au contact " + contact.getName() + " avec SID: " + message.getSid());
            } catch (Exception e) {
                System.err.println("Erreur lors de l'envoi du SMS au contact " + contact.getName() + ": " + e.getMessage());
            }
        }
    }
}
